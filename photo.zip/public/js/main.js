window.onload=function(){
  $('.tt').tooltip('enable');
}
