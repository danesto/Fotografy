>>> print("Dane")

