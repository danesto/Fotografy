<div class="container mt-5">
    <div class="row">
<div class="col-md-3 vertical-menu">
    <ul class="list-group list-group-flush">
        <li class="list-group-item bg-dark mb-3"><a class="text-white" href="{{asset('admin/')}}" >ADMIN</a></li>
        <li class="list-group-item bg-dark mb-3"><a class="text-white"href="{{asset('admin/users')}}">Manage users</a></li>
        <li class="list-group-item bg-dark mb-3"><a class="text-white" href="{{asset('admin/posts')}}">Manage posts</a></li>
        <li class="list-group-item bg-dark mb-3"><a  class="text-white" href="{{asset('admin/activity')}}">Activities</a></li>

    </ul>
</div>
