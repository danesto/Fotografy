
<div class="container mt-5">
    <nav class="navbar navbar-light bg-white shadow-lg p-3">
        <a class="text-dark" href="{{asset('index')}}">Fotografy</a>
        <a class="text-info" href="{{asset('author')}}">Copyright &copy; Danilo Stojanovic</a>
        <a class="float-right text-info" href="{{asset('storage/Dokumentacija.pdf')}}">Documentation</a>
    </nav>
</div>

</body>
</html>