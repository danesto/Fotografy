@include('partials/head')
@include('partials/nav')
@yield('sadrzaj')
@include('partials/footer')

