<?php
/**
 * Created by PhpStorm.
 * User: Development
 * Date: 2/28/2019
 * Time: 3:20 PM
 */

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Sort extends Controller
{

}