<?php
/**
 * Created by PhpStorm.
 * User: Development
 * Date: 3/1/2019
 * Time: 11:07 AM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Categories extends Model
{
    protected $table='category';
}